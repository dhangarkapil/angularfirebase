export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAdiox12IB1dM6GRnyH04tYlcfht4YCTyQ",
    authDomain: "commentary-staging.firebaseapp.com",
    databaseURL: "https://commentary-staging.firebaseio.com",
    projectId: "commentary-staging",
    storageBucket: "commentary-staging.appspot.com",
    messagingSenderId: "752294823320"
  }
};
