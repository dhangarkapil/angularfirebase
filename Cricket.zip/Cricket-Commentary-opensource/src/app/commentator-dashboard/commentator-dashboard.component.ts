import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commentator-dashboard',
  templateUrl: './commentator-dashboard.component.html',
  styleUrls: ['./commentator-dashboard.component.scss']
})
export class CommentatorDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
