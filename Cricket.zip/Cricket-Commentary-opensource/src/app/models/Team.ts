export class Team {
    name: string;
    players: string[];
}