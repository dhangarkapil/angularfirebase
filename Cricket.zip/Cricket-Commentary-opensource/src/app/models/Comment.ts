export class Comment {
    over: number;
    ball: number;
    bowler: string;
    batsman: string;
    comment: string;
}